package com.example.utponiente

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
