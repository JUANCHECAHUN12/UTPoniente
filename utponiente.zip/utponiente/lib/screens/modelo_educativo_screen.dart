import 'package:flutter/material.dart';

class ModeloEducativoScreen extends StatefulWidget {
  const ModeloEducativoScreen({ Key? key }) : super(key: key);

  @override
  _ModeloEducativoScreenState createState() => _ModeloEducativoScreenState();
}

class _ModeloEducativoScreenState extends State<ModeloEducativoScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Modelo Educativo"),
      ),
    );
  }
}
